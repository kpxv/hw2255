.\objects\queue_circular_fifo.o: Queue_Circular_FIFO.c
.\objects\queue_circular_fifo.o: Queue_Circular_FIFO.h
